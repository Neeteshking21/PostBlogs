import { Fragment } from 'react'
import { useSelector } from 'react-redux'
import NavBar from './Navbar'
import Articals from './Articals'
import CreateBox from './CreateBox'
import './Home.css'

const Home = (props) => {
    return (
        <Fragment>
            <div id='component-dashboard-home-main'>
                <NavBar />
                <CreateBox />
                <Articals />
            </div>
        </Fragment>
    )
}

export default Home;